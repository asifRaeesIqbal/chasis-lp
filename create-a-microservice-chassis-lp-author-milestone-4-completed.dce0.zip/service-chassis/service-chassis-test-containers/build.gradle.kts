dependencies {

    implementation("org.testcontainers:testcontainers")
    implementation("org.testcontainers:junit-jupiter")
    implementation("org.testcontainers:mysql")
    implementation("org.springframework.boot:spring-boot-starter-test")


}
