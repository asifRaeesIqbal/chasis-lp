apply<RestAssuredDependenciesPlugin>()

dependencies {
    implementation("org.keycloak:keycloak-admin-client")
    implementation("org.springframework.boot:spring-boot-starter")
    implementation("org.springframework.boot:spring-boot-starter-test")


}
