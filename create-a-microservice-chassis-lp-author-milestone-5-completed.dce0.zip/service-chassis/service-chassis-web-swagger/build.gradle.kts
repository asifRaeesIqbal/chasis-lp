
dependencies {
    implementation(project(":service-chassis-web"))

    api("org.springdoc:springdoc-openapi-ui")

}
