const val dockerComposePluginVersion="0.14.12"
const val springBootVersion = "2.6.2"
