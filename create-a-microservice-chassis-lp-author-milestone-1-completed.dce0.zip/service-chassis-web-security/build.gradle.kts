
dependencies {

    api(project(":service-chassis-domain-security"))

    api("org.springframework.boot:spring-boot-starter-oauth2-resource-server")

}
