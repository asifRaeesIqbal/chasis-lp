package net.chrisrichardson.liveprojects.servicechassis.security.keycloak

import org.springframework.context.annotation.ComponentScan
import org.springframework.context.annotation.Configuration

@Configuration
@ComponentScan
class KeyCloakTestConfiguration {
}
