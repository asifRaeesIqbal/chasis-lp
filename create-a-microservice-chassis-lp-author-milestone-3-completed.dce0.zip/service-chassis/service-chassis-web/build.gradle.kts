
dependencies {
    api("org.springframework.boot:spring-boot-starter-web")
}
