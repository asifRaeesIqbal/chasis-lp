plugins {
    id("net.chrisrichardson.liveprojects.servicechassis.plugins.ServiceWebSecurityModulePlugin")
}
